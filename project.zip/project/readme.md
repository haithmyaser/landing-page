# Landing Page Project

We were assigend to design a Landing page

# Author

My Name is Haithm Yasser

# Content

This file contains 3 objects
1- is css file that you have already given to me
2- html file that already has been given to me with an updated value o
creating section 4
3- app.js and it contains the javascript code
4- the readme file that you're reading right now

# Description

That's a fully responsive landing page with many features like highlight
on view and a responsive navigation bar

# Steps

first I worked on the navbar to display it
then I connected it to my section using a loop
that was the hard part for me really
I used getBoundingClientRect() as you asked and searched what is the
best way to use it and I think You will be happy with the results

# Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open js/app.js and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.











