//** start main functions   **//

//** Creating Navigation bar linked to sections **//
const allSections = document.querySelectorAll("section");
const navBar = document.querySelector("#navbar__list");
let fragment = document.createDocumentFragment();
let listele = "";
//** looping  **//
function createNavBar() {
  allSections.forEach((section) => {
    const listContent = document.createElement("li");
    listContent.innerHTML = `<li><a href="#${section.id}" data-nav="${section.id}" class="menu__link">${section.dataset.nav}</a>`;
    listContent.addEventListener("click", (action) => {
      action.preventDefault();
      section.scrollIntoView({ behavior: "smooth" });
    });
    fragment.appendChild(listContent);
  });
  navBar.appendChild(fragment);
}
createNavBar();

//** Highligh section on view using getbounding client **//
const links = document.querySelectorAll("a.menu__link");
window.addEventListener("scroll", (active) => {
  for (const section of allSections) {
    const secTop = section.getBoundingClientRect().top;
    if (secTop > -50 && secTop <= 300) {
      section.classList.add("your-active-class");
      links.forEach((link) => {
        link.classList.remove("active-link");
        if (link.textContent === section.dataset.nav) {
          link.classList.add("active-link");
        } else {
          link.classList.remove("active-link");
        }
      });
    } else {
      section.classList.remove("your-active-class");
    }
  }
});

// creating To Top button

let span = document.querySelector("#to-top");

span.onclick = function () {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
};
document.onscroll = function () {
  window.scrollY > 500
    ? (span.style.display = "block")
    : (span.style.display = "none");
};
